import { useMemo } from "react";
import { useParams, Link } from "wouter";
import { ArrowLeft, Trophy, AlertCircle, CheckCircle2, XCircle } from "lucide-react";
import { useAppContext } from "@/context/AppContext";
import { getTeamName, getTeamFlag } from "@/lib/utils";
import { Metric } from "@/context/AppContext";

function MetricBar({ metric }: { metric: Metric }) {
  const total = metric.t1.value + metric.t2.value || 1;
  const pct1 = Math.round((metric.t1.value / total) * 100);
  const pct2 = 100 - pct1;
  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-center justify-between text-xs font-bold">
        <span className={metric.t1.status === "win" ? "text-[#00FF87]" : "text-gray-400"}>{metric.t1.value}%</span>
        <span className="text-gray-400 uppercase tracking-wide text-[10px]">{metric.label}</span>
        <span className={metric.t2.status === "win" ? "text-[#00FF87]" : "text-gray-400"}>{metric.t2.value}%</span>
      </div>
      <div className="h-2 flex rounded-full overflow-hidden gap-0.5">
        <div className="rounded-l-full" style={{ width: `${pct1}%`, backgroundColor: metric.t1.status === "win" ? "#00FF87" : "#1F2D3D" }}></div>
        <div className="rounded-r-full flex-1" style={{ backgroundColor: metric.t2.status === "win" ? "#0077FF" : "#1F2D3D" }}></div>
      </div>
    </div>
  );
}

export default function PredictionDetails() {
  const params = useParams<{ key: string }>();
  const predKey = params.key || "";
  const { globalData } = useAppContext();

  const pred = globalData?.Prediction?.[predKey];
  const t1Name = pred ? getTeamName(pred.teams.t1.name) : "";
  const t2Name = pred ? getTeamName(pred.teams.t2.name) : "";

  if (!pred) {
    return (
      <main className="flex flex-col items-center justify-center min-h-[60vh] gap-4 page-transition">
        <div className="text-6xl">🎯</div>
        <p className="text-white font-bold text-xl">Prediction not found</p>
        <Link href="/sports/prediction" className="text-[#0077FF] text-sm font-bold hover:underline">← Back to Predictions</Link>
      </main>
    );
  }

  return (
    <main className="flex flex-col gap-8 px-8 md:px-12 py-8 page-transition max-w-4xl mx-auto w-full">
      <Link href="/sports/prediction" className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors w-fit">
        <ArrowLeft className="w-4 h-4" /> <span className="text-sm font-medium">Back to Predictions</span>
      </Link>

      <div className="flex flex-col gap-3">
        <div className="flex items-center gap-3 flex-wrap">
          <span className="px-3 py-1 bg-[#FF003C]/10 text-[#FF003C] text-xs font-bold uppercase tracking-wider rounded-full">{pred.category}</span>
          {pred.predictionSettings.enablePrediction && (
            <span className="flex items-center gap-1 px-3 py-1 bg-amber-500/10 text-amber-400 text-xs font-bold uppercase tracking-wider rounded-full">
              <Trophy className="w-3 h-3" /> Active Prediction
            </span>
          )}
        </div>
        <h1 className="text-2xl md:text-3xl font-black text-white leading-tight">{t1Name} vs {t2Name}</h1>
        <p className="text-gray-400 text-sm">{pred.matchTitle} — {pred.subtitle}</p>
      </div>

      {/* Teams */}
      <div className="grid grid-cols-7 gap-4 items-center bg-[#111827] border border-white/5 rounded-2xl p-6">
        <div className="col-span-3 flex flex-col items-center gap-3">
          <div className="w-20 h-20 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center p-3">
            <img referrerPolicy="no-referrer" src={getTeamFlag(pred.teams.t1.logo)} alt={t1Name} className="w-full h-full object-contain" onError={e => (e.currentTarget.style.display = "none")} />
          </div>
          <span className="text-white font-bold text-base text-center">{t1Name}</span>
          <span className="text-[10px] text-gray-500 uppercase tracking-wider">Home</span>
        </div>
        <div className="col-span-1 flex justify-center">
          <div className="w-10 h-10 bg-[#0B111A] border border-white/5 rounded-full flex items-center justify-center">
            <span className="text-[9px] font-black text-gray-500 uppercase">VS</span>
          </div>
        </div>
        <div className="col-span-3 flex flex-col items-center gap-3">
          <div className="w-20 h-20 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center p-3">
            <img referrerPolicy="no-referrer" src={getTeamFlag(pred.teams.t2.logo)} alt={t2Name} className="w-full h-full object-contain" onError={e => (e.currentTarget.style.display = "none")} />
          </div>
          <span className="text-white font-bold text-base text-center">{t2Name}</span>
          <span className="text-[10px] text-gray-500 uppercase tracking-wider">Away</span>
        </div>
      </div>

      {/* Analysis */}
      <div className="flex flex-col gap-4 p-6 bg-[#111827] border border-white/5 rounded-2xl">
        <h2 className="text-lg font-black text-white uppercase tracking-wider">Match Analysis</h2>
        <p className="text-gray-400 text-sm leading-relaxed">{pred.analysis.description}</p>
        {pred.analysis.bulletPoints && pred.analysis.bulletPoints.length > 0 && (
          <ul className="flex flex-col gap-2">
            {pred.analysis.bulletPoints.map((bp, i) => (
              <li key={i} className="flex items-start gap-2 text-gray-400 text-sm">
                <CheckCircle2 className="w-4 h-4 text-[#00FF87] mt-0.5 shrink-0" />
                <span>{bp}</span>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Metrics */}
      {pred.analysis.metrics && pred.analysis.metrics.length > 0 && (
        <div className="flex flex-col gap-5 p-6 bg-[#111827] border border-white/5 rounded-2xl">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-black text-white uppercase tracking-wider">Head to Head Stats</h2>
            <div className="flex items-center gap-4 text-xs font-bold">
              <span className="flex items-center gap-1 text-[#00FF87]"><CheckCircle2 className="w-3 h-3" /> {t1Name}</span>
              <span className="flex items-center gap-1 text-[#0077FF]"><CheckCircle2 className="w-3 h-3" /> {t2Name}</span>
            </div>
          </div>
          <div className="flex flex-col gap-4">
            {pred.analysis.metrics.map((m, i) => <MetricBar key={i} metric={m} />)}
          </div>
        </div>
      )}

      {/* Prediction options */}
      {pred.predictionSettings.enablePrediction && pred.predictionSettings.options && pred.predictionSettings.options.length > 0 && (
        <div className="flex flex-col gap-4 p-6 bg-[#111827] border border-amber-500/20 rounded-2xl">
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg font-black text-white uppercase tracking-wider">Prediction</h2>
          </div>
          {pred.predictionSettings.scorePredictionText && (
            <p className="text-gray-400 text-sm">{pred.predictionSettings.scorePredictionText}</p>
          )}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {pred.predictionSettings.options.map((opt, i) => (
              <div key={i} className="p-4 bg-[#0B111A] border border-white/5 rounded-xl flex flex-col gap-1">
                <span className="text-xs text-gray-500 uppercase tracking-wider font-bold">{opt.title}</span>
                <span className="text-white font-bold text-sm">{opt.outcome}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </main>
  );
}
