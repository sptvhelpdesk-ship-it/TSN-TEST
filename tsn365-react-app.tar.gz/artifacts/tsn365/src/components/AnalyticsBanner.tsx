import { Link } from "wouter";
import { ArrowRight, Trophy, Play } from "lucide-react";

interface Props {
  variant?: "predictions" | "live";
}

export default function AnalyticsBanner({ variant = "predictions" }: Props) {
  if (variant === "live") {
    return (
      <div className="bg-gradient-to-r from-[#111827] to-[#15212D] border border-amber-500/20 rounded-3xl p-8 md:p-12 flex flex-col md:flex-row justify-between items-center gap-8 relative overflow-hidden shadow-2xl min-h-[180px] md:min-h-[220px]">
        <div className="absolute -right-16 -bottom-16 w-64 h-64 bg-[#FF003C]/5 rounded-full blur-3xl"></div>
        <div className="flex items-start gap-5">
          <div className="w-16 h-16 md:w-20 md:h-20 rounded-2xl bg-red-500/10 flex items-center justify-center border border-red-500/20 shrink-0 text-[#FF003C] shadow-xl">
            <Play className="w-9 h-9 md:w-11 md:h-11 fill-[#FF003C]" />
          </div>
          <div className="space-y-1.5">
            <h3 className="text-xl md:text-3xl font-black text-white tracking-wide uppercase leading-tight">Watch Live Action</h3>
            <p className="text-gray-400 text-xs md:text-sm mt-1 max-w-xl leading-relaxed">Unlock advanced player statistics, pitch reports, and expert predictions for all active matches.</p>
          </div>
        </div>
        <Link href="/sports/live" className="px-8 py-4 bg-[#FF003C] hover:bg-[#D60032] text-white font-black text-xs md:text-sm uppercase tracking-widest rounded-xl transition-all shadow-lg shadow-red-500/15 shrink-0 flex items-center gap-2.5">
          <span>Go to Live</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-r from-[#111827] to-[#15212D] border border-white/10 rounded-3xl p-8 md:p-12 flex flex-col md:flex-row justify-between items-center gap-8 relative overflow-hidden shadow-2xl min-h-[180px] md:min-h-[220px]">
      <div className="absolute -right-16 -bottom-16 w-64 h-64 bg-[#00FF87]/5 rounded-full blur-3xl"></div>
      <div className="flex items-start gap-5">
        <div className="w-16 h-16 md:w-20 md:h-20 rounded-2xl bg-emerald-500/10 flex items-center justify-center border border-emerald-500/20 shrink-0 text-[#00FF87] shadow-xl">
          <Trophy className="w-9 h-9 md:w-11 md:h-11" />
        </div>
        <div className="space-y-1.5">
          <h3 className="text-xl md:text-3xl font-black text-white tracking-wide uppercase leading-tight">Full Sport Analytics</h3>
          <p className="text-gray-400 text-xs md:text-sm mt-1 max-w-xl leading-relaxed">Unlock advanced player statistics, pitch reports, and expert predictions for all active matches.</p>
        </div>
      </div>
      <Link href="/sports/prediction" className="px-8 py-4 bg-[#00FF87] hover:bg-[#00D670] text-black font-black text-xs uppercase tracking-widest rounded-xl transition-all shadow-lg shadow-emerald-500/15 shrink-0 flex items-center gap-2.5">
        <span>Get Predictions</span>
        <ArrowRight className="w-4 h-4" />
      </Link>
    </div>
  );
}
